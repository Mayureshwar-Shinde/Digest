package com.ashokit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;


@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		String apiUrl = "http://localhost:8080/ashok/msg";
		
		HttpHeaders headers = new HttpHeaders();
		headers.setBasicAuth("admin", "password");
		HttpEntity<String> reqEntity = new HttpEntity<>(headers);
		
		RestTemplate rt = new RestTemplate();
		ResponseEntity<String> response = rt.exchange(apiUrl, HttpMethod.GET, reqEntity, String.class);
		// ResponseEntity<String> response = rt.getForEntity(apiUrl, String.class);
		
		System.out.println(response.getBody());
	}

}

