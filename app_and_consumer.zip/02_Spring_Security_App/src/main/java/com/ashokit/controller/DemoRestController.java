package com.ashokit.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/ashok")
public class DemoRestController {
	
	@GetMapping
	public String home() {
		return "/ashok-home";
	}
	
	@GetMapping("/msg")
	public String getMsg() {
		return "Good morning";
	}
	
}
